import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class LocalDbService {
  LocalDbService._();

  static final LocalDbService instance = LocalDbService._();

  Database? _database;

  Database get database {
    final value = _database;
    if (value == null) {
      throw StateError('Local database has not been initialized.');
    }
    return value;
  }

  Future<void> init() async {
    if (_database != null) return;

    final supportDirectory = await getApplicationSupportDirectory();
    final dbPath = p.join(supportDirectory.path, 'labscan_itso.db');

    _database = await databaseFactory.openDatabase(
      dbPath,
      options: OpenDatabaseOptions(
        version: 2,
        onCreate: _createDatabase,
        onUpgrade: _upgradeDatabase,
      ),
    );
  }

  Future<void> _createDatabase(Database db, int version) async {
    await db.execute('''
      CREATE TABLE student_logs (
        id TEXT PRIMARY KEY,
        studentEmail TEXT NOT NULL,
        windowsUsername TEXT NOT NULL,
        pcNumber TEXT NOT NULL,
        room TEXT NOT NULL,
        loginTime TEXT NOT NULL,
        logoutTime TEXT,
        formSubmitted INTEGER NOT NULL DEFAULT 1,
        sessionStatus TEXT NOT NULL DEFAULT 'active',
        syncStatus TEXT NOT NULL DEFAULT 'pending'
      )
    ''');

    await db.execute('''
      CREATE TABLE issue_reports (
        id TEXT PRIMARY KEY,
        studentEmail TEXT NOT NULL,
        pcNumber TEXT NOT NULL,
        room TEXT NOT NULL,
        issueType TEXT NOT NULL,
        description TEXT NOT NULL,
        severity TEXT NOT NULL,
        status TEXT NOT NULL,
        source TEXT NOT NULL,
        detectedBySystem INTEGER NOT NULL DEFAULT 0,
        teacherNotified INTEGER NOT NULL DEFAULT 0,
        createdAt TEXT NOT NULL,
        syncStatus TEXT NOT NULL DEFAULT 'pending'
      )
    ''');

    await db.execute('''
      CREATE TABLE troubleshooting_guides (
        id TEXT PRIMARY KEY,
        issueType TEXT NOT NULL,
        suggestion TEXT NOT NULL
      )
    ''');

    await _seedLocalGuides(db);
  }

  Future<void> _upgradeDatabase(
    Database db,
    int oldVersion,
    int newVersion,
  ) async {
    if (oldVersion < 2) {
      try {
        await db.execute('ALTER TABLE student_logs ADD COLUMN logoutTime TEXT');
      } catch (_) {}
      try {
        await db.execute(
          "ALTER TABLE student_logs ADD COLUMN sessionStatus TEXT NOT NULL DEFAULT 'active'",
        );
      } catch (_) {}
    }
  }

  Future<void> _seedLocalGuides(Database db) async {
    const rows = [
      {
        'id': 'mouse_not_detected',
        'issueType': 'mouse',
        'suggestion': 'Reconnect the mouse and test another USB port.',
      },
      {
        'id': 'keyboard_not_detected',
        'issueType': 'keyboard',
        'suggestion': 'Reconnect the keyboard and test another USB port.',
      },
      {
        'id': 'monitor_not_detected',
        'issueType': 'monitor',
        'suggestion': 'Check the monitor power and display cable.',
      },
      {
        'id': 'network_not_detected',
        'issueType': 'network',
        'suggestion': 'Check the Ethernet cable and network adapter.',
      },
      {
        'id': 'storage_warning',
        'issueType': 'storage',
        'suggestion': 'Save your work and notify ITSO about the storage warning.',
      },
    ];

    for (final row in rows) {
      await db.insert(
        'troubleshooting_guides',
        row,
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
  }

  Future<void> insertStudentLog(Map<String, dynamic> data) async {
    await database.insert(
      'student_logs',
      data,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> insertIssueReport(Map<String, dynamic> data) async {
    await database.insert(
      'issue_reports',
      data,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> getPendingStudentLogs() {
    return database.query(
      'student_logs',
      where: 'syncStatus = ?',
      whereArgs: ['pending'],
      orderBy: 'loginTime ASC',
    );
  }

  Future<List<Map<String, dynamic>>> getPendingIssueReports() {
    return database.query(
      'issue_reports',
      where: 'syncStatus = ?',
      whereArgs: ['pending'],
      orderBy: 'createdAt ASC',
    );
  }

  Future<List<Map<String, dynamic>>> getAllStudentLogs() {
    return database.query('student_logs', orderBy: 'loginTime DESC');
  }

  Future<List<Map<String, dynamic>>> getAllIssueReports() {
    return database.query('issue_reports', orderBy: 'createdAt DESC');
  }

  Future<void> markSynced(String table, String id) async {
    if (table != 'student_logs' && table != 'issue_reports') {
      throw ArgumentError('Unsupported table: $table');
    }
    await database.update(
      table,
      {'syncStatus': 'synced'},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> markStudentSessionEnded(String id) async {
    await database.update(
      'student_logs',
      {
        'logoutTime': DateTime.now().toIso8601String(),
        'sessionStatus': 'completed',
        'syncStatus': 'pending',
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<List<String>> getSuggestions(String issueType) async {
    final rows = await database.query(
      'troubleshooting_guides',
      columns: ['suggestion'],
      where: 'issueType = ?',
      whereArgs: [issueType],
    );
    return rows.map((row) => row['suggestion'].toString()).toList();
  }

  Future<int> pendingCount() async {
    final logs = await getPendingStudentLogs();
    final reports = await getPendingIssueReports();
    return logs.length + reports.length;
  }
}
