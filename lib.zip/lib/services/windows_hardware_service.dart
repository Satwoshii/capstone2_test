import 'dart:io';

class HardwareCheckResult {
  final bool mouseDetected;
  final bool keyboardDetected;
  final bool monitorDetected;
  final bool networkDetected;
  final bool storageHealthy;
  final List<String> warnings;

  const HardwareCheckResult({
    required this.mouseDetected,
    required this.keyboardDetected,
    required this.monitorDetected,
    required this.networkDetected,
    required this.storageHealthy,
    required this.warnings,
  });

  List<String> get failedComponents {
    final failed = <String>[];
    if (!mouseDetected) failed.add('mouse');
    if (!keyboardDetected) failed.add('keyboard');
    if (!monitorDetected) failed.add('monitor');
    if (!networkDetected) failed.add('network');
    if (!storageHealthy) failed.add('storage');
    return failed;
  }
}

class WindowsHardwareService {
  WindowsHardwareService._();

  static Future<String> _runPowerShell(String command) async {
    if (!Platform.isWindows) return '';
    try {
      final result = await Process.run(
        'powershell.exe',
        ['-NoProfile', '-NonInteractive', '-Command', command],
        runInShell: false,
      ).timeout(const Duration(seconds: 15));
      if (result.exitCode != 0) return '';
      return result.stdout.toString().trim();
    } catch (_) {
      return '';
    }
  }

  static Future<bool> _hasWorkingDevice(String pnpClass) async {
    final output = await _runPowerShell(
      "Get-PnpDevice -Class '$pnpClass' -ErrorAction SilentlyContinue | "
      "Where-Object { \$_.Status -eq 'OK' } | Select-Object -First 1 "
      "-ExpandProperty InstanceId",
    );
    return output.isNotEmpty;
  }

  static Future<bool> _networkIsUp() async {
    final output = await _runPowerShell(
      "Get-NetAdapter -ErrorAction SilentlyContinue | "
      "Where-Object { \$_.Status -eq 'Up' -and \$_.HardwareInterface } | "
      "Select-Object -First 1 -ExpandProperty Name",
    );
    return output.isNotEmpty;
  }

  static Future<bool> _storageIsHealthy() async {
    final output = await _runPowerShell(
      "Get-PhysicalDisk -ErrorAction SilentlyContinue | "
      "Where-Object { \$_.HealthStatus -ne 'Healthy' } | "
      "Select-Object -First 1 -ExpandProperty FriendlyName",
    );
    return output.isEmpty;
  }

  static Future<List<String>> getRecentHardwareWarnings() async {
    final output = await _runPowerShell(
      r'''Get-WinEvent -FilterHashtable @{LogName='System'; Level=2,3; StartTime=(Get-Date).AddHours(-2)} -MaxEvents 8 -ErrorAction SilentlyContinue | ForEach-Object { "$($_.TimeCreated) | $($_.ProviderName) | ID $($_.Id) | $($_.Message -replace '[\r\n]+',' ')" }''',
    );
    if (output.isEmpty) return const [];
    return output
        .split(RegExp(r'\r?\n'))
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty)
        .take(8)
        .toList();
  }

  static Future<HardwareCheckResult> checkHardware() async {
    if (!Platform.isWindows) {
      return const HardwareCheckResult(
        mouseDetected: true,
        keyboardDetected: true,
        monitorDetected: true,
        networkDetected: true,
        storageHealthy: true,
        warnings: [],
      );
    }

    final values = await Future.wait<dynamic>([
      _hasWorkingDevice('Mouse'),
      _hasWorkingDevice('Keyboard'),
      _hasWorkingDevice('Monitor'),
      _networkIsUp(),
      _storageIsHealthy(),
      getRecentHardwareWarnings(),
    ]);

    return HardwareCheckResult(
      mouseDetected: values[0] as bool,
      keyboardDetected: values[1] as bool,
      monitorDetected: values[2] as bool,
      networkDetected: values[3] as bool,
      storageHealthy: values[4] as bool,
      warnings: values[5] as List<String>,
    );
  }
}
