import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';

import 'firebase_bootstrap_service.dart';
import 'local_db_service.dart';

class SyncService {
  SyncService._();

  static final SyncService instance = SyncService._();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final ValueNotifier<bool> isSyncing = ValueNotifier<bool>(false);
  final ValueNotifier<int> pendingItems = ValueNotifier<int>(0);

  StreamSubscription<List<ConnectivityResult>>? _subscription;
  Timer? _retryTimer;
  bool _started = false;

  Future<void> start() async {
    if (_started) return;
    _started = true;

    await refreshPendingCount();
    unawaited(syncPendingData());

    _subscription = Connectivity().onConnectivityChanged.listen((results) {
      if (!results.contains(ConnectivityResult.none)) {
        unawaited(syncPendingData());
      }
    });

    _retryTimer = Timer.periodic(
      const Duration(minutes: 2),
      (_) => unawaited(syncPendingData()),
    );
  }

  Future<void> dispose() async {
    await _subscription?.cancel();
    _retryTimer?.cancel();
    _subscription = null;
    _retryTimer = null;
    _started = false;
  }

  Future<void> refreshPendingCount() async {
    try {
      pendingItems.value = await LocalDbService.instance.pendingCount();
    } catch (_) {
      pendingItems.value = 0;
    }
  }

  Future<void> syncPendingData() async {
    if (isSyncing.value) return;
    isSyncing.value = true;

    try {
      await FirebaseBootstrapService.instance.initialize();
      await _syncStudentLogs();
      await _syncIssueReports();
    } on FirebaseException catch (error) {
      debugPrint('Firebase sync postponed: ${error.code} ${error.message}');
    } catch (error) {
      debugPrint('Firebase sync postponed: $error');
    } finally {
      isSyncing.value = false;
      await refreshPendingCount();
    }
  }

  Future<void> _syncStudentLogs() async {
    final rows = await LocalDbService.instance.getPendingStudentLogs();
    for (final row in rows) {
      final id = row['id'].toString();
      await _firestore.collection('student_logs').doc(id).set({
        'id': id,
        'studentEmail': row['studentEmail'],
        'windowsUsername': row['windowsUsername'],
        'pcNumber': row['pcNumber'],
        'room': row['room'],
        'loginTime': row['loginTime'],
        'logoutTime': row['logoutTime'],
        'sessionStatus': row['sessionStatus'],
        'formSubmitted': row['formSubmitted'] == 1,
        'syncStatus': 'synced',
        'syncedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      await LocalDbService.instance.markSynced('student_logs', id);
    }
  }

  Future<void> _syncIssueReports() async {
    final rows = await LocalDbService.instance.getPendingIssueReports();
    for (final row in rows) {
      final id = row['id'].toString();
      final batch = _firestore.batch();

      batch.set(
        _firestore.collection('issue_reports').doc(id),
        {
          'id': id,
          'studentEmail': row['studentEmail'],
          'pcNumber': row['pcNumber'],
          'room': row['room'],
          'issueType': row['issueType'],
          'description': row['description'],
          'severity': row['severity'],
          'status': row['status'],
          'source': row['source'],
          'detectedBySystem': row['detectedBySystem'] == 1,
          'teacherNotified': true,
          'createdAt': row['createdAt'],
          'syncStatus': 'synced',
          'syncedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );

      batch.set(
        _firestore.collection('teacher_notifications').doc(id),
        {
          'reportId': id,
          'pcNumber': row['pcNumber'],
          'room': row['room'],
          'studentEmail': row['studentEmail'],
          'issueType': row['issueType'],
          'description': row['description'],
          'status': 'unread',
          'createdAt': row['createdAt'],
          'syncedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );

      await batch.commit();
      await LocalDbService.instance.markSynced('issue_reports', id);
    }
  }
}
