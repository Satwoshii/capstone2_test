class IssueReport {
  final String id;
  final String studentEmail;
  final String pcNumber;
  final String room;
  final String issueType;
  final String description;
  final String severity;
  final String status;
  final String source;
  final bool detectedBySystem;
  final bool teacherNotified;
  final DateTime createdAt;
  final String syncStatus;

  const IssueReport({
    required this.id,
    required this.studentEmail,
    required this.pcNumber,
    required this.room,
    required this.issueType,
    required this.description,
    required this.createdAt,
    this.severity = 'medium',
    this.status = 'unresolved',
    this.source = 'student_pc_form',
    this.detectedBySystem = false,
    this.teacherNotified = false,
    this.syncStatus = 'pending',
  });

  Map<String, dynamic> toLocalMap() {
    return {
      'id': id,
      'studentEmail': studentEmail,
      'pcNumber': pcNumber,
      'room': room,
      'issueType': issueType,
      'description': description,
      'severity': severity,
      'status': status,
      'source': source,
      'detectedBySystem': detectedBySystem ? 1 : 0,
      'teacherNotified': teacherNotified ? 1 : 0,
      'createdAt': createdAt.toIso8601String(),
      'syncStatus': syncStatus,
    };
  }
}
