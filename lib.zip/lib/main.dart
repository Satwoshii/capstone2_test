import 'dart:io';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:window_manager/window_manager.dart';

import 'firebase_options.dart';
import 'screens/role_select_screen.dart';
import 'services/local_db_service.dart';
import 'services/startup_service.dart';
import 'services/sync_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final bool isDesktop =
      Platform.isWindows || Platform.isLinux || Platform.isMacOS;

  /*
   * Initialize the local SQLite database on desktop.
   *
   * The phone application is only used for QR authentication,
   * so it does not need the desktop SQLite database.
   */
  if (isDesktop) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;

    try {
      await LocalDbService.instance.init();
      debugPrint('Local SQLite database initialized.');
    } catch (error, stackTrace) {
      debugPrint('Local database initialization failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  /*
   * Initialize Firebase.
   *
   * The named Firestore database "data" is selected inside
   * firebase_service.dart, not here.
   */
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );

    debugPrint(
      'Firebase initialized: ${Firebase.app().options.projectId}',
    );
  } catch (error, stackTrace) {
    debugPrint('Firebase initialization failed: $error');
    debugPrintStack(stackTrace: stackTrace);
  }

  /*
   * Configure the Windows/macOS/Linux desktop window.
   */
  if (isDesktop) {
    try {
      await windowManager.ensureInitialized();

      const windowOptions = WindowOptions(
        minimumSize: Size(900, 650),
        center: true,
        title: 'NU Clark ITSO Monitoring System',
      );

      await windowManager.waitUntilReadyToShow(
        windowOptions,
            () async {
          await windowManager.maximize();
          await windowManager.show();
          await windowManager.focus();

          // Prevents normal closing of the window.
          // This is not a complete Windows kiosk lock.
          await windowManager.setPreventClose(true);
        },
      );
    } catch (error, stackTrace) {
      debugPrint('Window initialization failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    }

    /*
     * Automatically launch the PC application when Windows starts.
     */
    try {
      await StartupService.enableStartup();
      debugPrint('Startup launch enabled.');
    } catch (error, stackTrace) {
      debugPrint('Unable to enable startup launch: $error');
      debugPrintStack(stackTrace: stackTrace);
    }

    /*
     * Start automatic SQLite-to-Firebase synchronization.
     */
    try {
      await SyncService.instance.start();
      debugPrint('Automatic synchronization started.');
    } catch (error, stackTrace) {
      /*
       * The app remains usable offline.
       * Unsynced records stay in SQLite as pending.
       */
      debugPrint('Automatic sync could not start: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  runApp(
    LabScanApp(
      isDesktop: isDesktop,
    ),
  );
}

class LabScanApp extends StatelessWidget {
  final bool isDesktop;

  const LabScanApp({
    super.key,
    required this.isDesktop,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NU Clark ITSO Monitoring System',
      debugShowCheckedModeBanner: false,

      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF003087),
        ),
        useMaterial3: true,
        inputDecorationTheme: const InputDecorationTheme(
          filled: true,
          border: OutlineInputBorder(),
        ),
        cardTheme: const CardThemeData(
          elevation: 2,
          margin: EdgeInsets.all(8),
        ),
      ),

      home: const RoleSelectScreen(),
    );
  }
}