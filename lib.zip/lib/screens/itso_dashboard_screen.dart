import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../widgets/status_card.dart';

class ItsoDashboardScreen extends StatefulWidget {
  const ItsoDashboardScreen({super.key});

  @override
  State<ItsoDashboardScreen> createState() => _ItsoDashboardScreenState();
}

class _ItsoDashboardScreenState extends State<ItsoDashboardScreen> {
  String _filter = 'all';

  Future<void> _resolve(
    String reportId,
    Map<String, dynamic> data,
  ) async {
    final firestore = FirebaseFirestore.instance;
    final user = FirebaseAuth.instance.currentUser;
    final reportReference = firestore.collection('issue_reports').doc(reportId);
    final historyReference = firestore.collection('maintenance_history').doc();
    final batch = firestore.batch();

    batch.update(reportReference, {
      'status': 'resolved',
      'resolvedAt': FieldValue.serverTimestamp(),
      'resolvedBy': user?.email ?? 'ITSO operator',
      'resolvedByUid': user?.uid,
    });
    batch.set(historyReference, {
      'reportId': reportId,
      'pcNumber': data['pcNumber'],
      'room': data['room'],
      'issueType': data['issueType'],
      'actionTaken': 'Marked as resolved by ITSO.',
      'performedBy': user?.email ?? 'ITSO operator',
      'performedByUid': user?.uid,
      'oldStatus': data['status'],
      'newStatus': 'resolved',
      'createdAt': FieldValue.serverTimestamp(),
    });
    await batch.commit();
  }

  @override
  Widget build(BuildContext context) {
    final stream = FirebaseFirestore.instance
        .collection('issue_reports')
        .orderBy('createdAt', descending: true)
        .snapshots();

    return Scaffold(
      appBar: AppBar(
        title: const Text('ITSO Report Dashboard'),
        actions: [
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _filter,
              items: const [
                DropdownMenuItem(value: 'all', child: Text('All reports')),
                DropdownMenuItem(value: 'unresolved', child: Text('Unresolved')),
                DropdownMenuItem(value: 'resolved', child: Text('Resolved')),
              ],
              onChanged: (value) {
                if (value != null) setState(() => _filter = value);
              },
            ),
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: stream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Unable to load reports: ${snapshot.error}'));
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final all = snapshot.data!.docs;
          final resolved = all.where((d) => d.data()['status'] == 'resolved').length;
          final unresolved = all.length - resolved;
          final filtered = all.where((doc) {
            if (_filter == 'all') return true;
            return doc.data()['status'] == _filter;
          }).toList();

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(14),
                child: LayoutBuilder(
                  builder: (_, constraints) {
                    final cards = [
                      StatusCard(title: 'Total reports', value: '${all.length}', icon: Icons.assignment),
                      StatusCard(title: 'Unresolved', value: '$unresolved', icon: Icons.warning),
                      StatusCard(title: 'Resolved', value: '$resolved', icon: Icons.check_circle),
                    ];
                    if (constraints.maxWidth < 720) {
                      return Column(children: cards);
                    }
                    return Row(
                      children: cards
                          .map((card) => Expanded(child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 4),
                                child: card,
                              )))
                          .toList(),
                    );
                  },
                ),
              ),
              Expanded(
                child: filtered.isEmpty
                    ? const Center(child: Text('No reports match this filter.'))
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                        itemCount: filtered.length,
                        itemBuilder: (_, index) {
                          final doc = filtered[index];
                          final data = doc.data();
                          final isResolved = data['status'] == 'resolved';
                          return Card(
                            child: ListTile(
                              leading: const Icon(Icons.computer),
                              title: Text('${data['pcNumber'] ?? 'PC'} • ${data['issueType'] ?? 'Issue'}'),
                              subtitle: Text(
                                'Room ${data['room'] ?? ''}\n'
                                '${data['studentEmail'] ?? ''}\n'
                                '${data['description'] ?? ''}',
                              ),
                              isThreeLine: true,
                              trailing: isResolved
                                  ? const Chip(label: Text('Resolved'))
                                  : FilledButton(
                                      onPressed: () => _resolve(doc.id, data),
                                      child: const Text('Resolve'),
                                    ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
